$(document).ready(function () {
  $(".slide").super({
    autoplay: true,
    arrowLeft: "<i class='fa-regular fa-circle-left fa-3x'></i>",
    arrowRight: "<i class='fa-regular fa-circle-right fa-3x'></i>",
    arrowElement: "<button style='background-color: white;'></button>",
  });
});
