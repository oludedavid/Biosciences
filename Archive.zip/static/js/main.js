const navigation = new Navigation(document.getElementById("navigation"));
